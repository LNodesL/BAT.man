# inc

Useful base64 function for when the program data is written to the .bat file in the C++ program.
