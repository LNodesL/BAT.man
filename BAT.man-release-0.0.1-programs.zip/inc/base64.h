#pragma once
#include <vector>
#include <string>

std::string toBase64(const std::vector<char>& data);
